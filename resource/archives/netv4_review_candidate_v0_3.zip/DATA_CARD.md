# NET-V4 candidate data card

Purpose: inspect event-conditioned center traffic forecasting and its sensitivity to source variant, scoring population, and error metric. History/horizon: 12/12 nominal 15-minute steps. Units: traffic volume per nominal interval; not speed, travel time, or physical recovery time.

Sources: NYC DOT Automated Traffic Volume Counts (7ym2-wayt) and FDNY Fire Incident Dispatch Data (8m42-w767). Fire records include medical responses but do not supply ambulance trajectories or certified lane occupation. Event masks describe generated perturbation intervals. Event targets are AR(1)-based profile realizations.

Packaged composition: 20000 generated event rows and 13076 generated control rows. Working composition: 20000 generated event rows, 12608 processed ATR-observation-tagged controls, and 468 bootstrap controls. Do not concatenate the two versions as independent samples. Source tags are provenance descriptors, not certificates of complete original measurement chronology.

Unknown or limited: original control dates, pointwise imputation provenance, exact neighboring identities and simultaneous observation times, online availability of final incident fields, observational traffic responses to the labeled events. Global 363-node graph metadata are not included in this local-window evaluation bundle, because this manuscript's models do not consume that graph. The legacy graph remains a separately described original asset.

Splits: fixed recorded-year train/validation/test indices per variant. Profiles may pool years; no assertion of untouched raw chronological generalization. Data and prior test results were seen during development. New experiment seeds only quantify model training variability.

Supported outputs: center MAE/RMSE/WMAPE for all steps, marked steps, marked windows, and whole event/control rows. Save exact indices and future scoring masks separately from model inputs.

Unsupported: real event causal effects, actual dispatch response recovery, routing gains, road-level synchronized propagation, borough fairness from sorted segment groups, or a claim that statistical jump bounds enforce traffic physics.

Identifiers are inherited public-source or constructed identifiers, not verified vehicle/patient records. They are supplied for grouping and provenance inspection, not for identifying people. No private access credentials or user filesystem paths are included.

Publication status: local candidate; no public URL, DOI, or archival deposit. Original NET-V4 rights text needs correction of the Fire source attribution. Final redistribution terms and author adoption are unresolved; STID's Apache-2.0 license is retained separately.

## v0.3 source and reproduction clarification

Official ATR metadata states that samples do not cover the whole year. Fire locations are aggregated; exact vehicle locations are not established. train.py reconstructs learning from the supplied snapshots, not the original data acquisition and generation. Two selected training reruns matched in the recorded environment; no fresh prospective test set or new research result was created. See SOURCE_ATTRIBUTION.md, COMPONENT_NOTICES.md, and TRAINING_VERIFICATION.json.
