# Component notices

| Component | Existing notice | Status |
|---|---|---|
| NET-V4 data | notices/NET_V4_DATA_DECLARATION_ORIGINAL.txt (CC BY 4.0 declaration) | Preserve historical notice; correct source attribution using SOURCE_ATTRIBUTION.md. Original ownership, upstream terms, and final release adoption are not newly verified. |
| Original project and excerpted generator | notices/PROJECT_MIT_ORIGINAL.txt | Existing MIT text retained verbatim, including copyright. |
| Legacy release code declaration | notices/NET_V4_CODE_DECLARATION_ORIGINAL.txt | Existing template retained; placeholder authors remain historical, not newly confirmed. |
| STID files under vendor/stid/arch | vendor/STID_LICENSE | Original Apache-2.0 text and code retained. |
| New evaluation/training and documentation | Proposed continuation of original project terms | No new blanket license or rightsholder fact is invented by this local assembly. Final rights adoption remains to be completed before release. |

Upstream NYC terms must be considered separately from rights in derived material. This is a record of existing declarations, not a statement that all data and code share one license. Notices required by existing licenses are retained even in this local review candidate.
