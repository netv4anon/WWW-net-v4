# -*- coding: utf-8 -*-
"""Replay the six disclosed construction fixtures; no data generation or fitting."""
import json
import numpy as np
from generator_excerpt import apply_ev_perturbation_v4 as fn
volumes=100+np.arange(24)*.2;baseline=np.full(24,100.0)
kw={"distance_deg":0.0,"severity_level":1,"dispatch_sec":300,"response_sec":600,"ev_start":10,"ev_duration":2}
np.random.seed(77);reference,mask=fn(volumes,baseline,**kw)
rows=[]
for step in [12,13,14,16,20,23]:
    altered=volumes.copy();altered[step]+=.01
    np.random.seed(77);response,new_mask=fn(altered,baseline,**kw)
    derivative=(response[step]-reference[step])/.01
    expected=1-np.exp(-(step-12)/2.0)
    assert abs(derivative-expected)<1e-10
    assert np.array_equal(mask,new_mask)
    rows.append({"step":step,"finite_difference":float(derivative),"formula":float(expected)})

print(json.dumps({"checked_cases":len(rows),"scope":"pure function fixtures, not empirical error attribution","cases":rows},indent=2))
