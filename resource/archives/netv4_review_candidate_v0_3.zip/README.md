# NET-V4 local review candidate v0.3

This package retains the two original NET-V4 snapshots, the 12-history to 12-future center forecasting task, and all sixteen saved model/seed predictions from v0.2. It adds portable training and component attribution. It is a local research candidate, not a deposited resource or a completed WWW submission.

## Replay without training

From the extracted directory:

```sh
python -B replay.py --check-only
python -B replay.py
python -B check_generator.py
```

The first command needs NumPy and verifies payload hashes and saved metrics. The second also reconstructs all predictions on CPU using saved weights; it needs PyTorch with weights_only support. The third checks six fixed finite-difference fixtures for an excerpted legacy generator function. No network, GPU, original project directory, or SUMO is required by these commands.

## Training from the supplied snapshots

Use the recorded environment in tested_environment.json and requirements.txt. For the original GPU configuration, install PyTorch 2.4.1 with CUDA 11.8 support from the official PyTorch distribution. A CPU wheel suffices for replay; retraining identity on other hardware has not been checked. Installing these dependencies into a fresh environment has not been tested here.

```sh
python -B train.py --variant packaged --model RidgeCenter --output ../rerun_packaged_ridge
python -B train.py --variant packaged --model STID_NoCalendar --seed 1 --device cuda --output ../rerun_packaged_stid_s1
```

Each output path must be new and outside this artifact. The data loader verifies snapshot hashes, uses training/validation targets, and replaces all test-target positions with NaN in the training interface. Prediction uses history only. For the same installed environment and device, these two selected training commands reproduced the frozen weights and predictions exactly; the STID selection epoch and all 30 validation values also matched. This is internal reproduction, not independent replication. See TRAINING_VERIFICATION.json. The two reruns are additional reproduction fits; the paper's ten research fits and main tables are unchanged.

The same entry accepts variant working, model RidgeLocal9, and STID seeds 1, 2, 3. Reconstructing every fitted configuration means two variants times two ridge models and three STID seeds (ten fits); that full retraining was not repeated for v0.3. Historical extrapolators are reconstructed by replay.py without fitting. Fixed settings: ridge alpha=1; STID 30 epochs, Adam 0.001, batch 256, gradient clip 3, nine-slot L1, center-validation checkpoint selection. Calendar embeddings are disabled. Final predictions are clipped nonnegative.

## Data and interpretation

data/*/history.npz contains only twelve past values for nine local slots. targets.npz supplies future values and offline scoring masks; analysis_metadata.npz supplies source and group identifiers. All NPZs load with allow_pickle=False. Analysis fields are not prediction inputs. Each variant has 33,076 rows; do not concatenate the snapshots as independent samples.

The packaged snapshot is fully generated. The working snapshot combines generated events with processed observation-tagged and bootstrap controls. These are dependent construction snapshots, not a controlled single-factor intervention. Recorded-year splits have been development-exposed; they do not certify independent raw chronological measurements. Read DATA_CARD.md and evaluation_contract.json before reuse.

The package supports forecasting and descriptive scoring investigations. It does not establish measured emergency-vehicle effects, real routing benefits, causal recovery times, or synchronized road propagation. generator_excerpt.py preserves historical comments verbatim; those comments are not validated physical claims. No complete raw-data-to-snapshot regeneration is claimed: historical downloads and processing cannot be fully reconstructed from this artifact.

## Rights and availability

Read COMPONENT_NOTICES.md. Preserved legacy notices contain an incorrect EMS source attribution and author/DOI placeholders; SOURCE_ATTRIBUTION.md supplies the verified Fire-source correction. The files under notices/ are historical declarations, not evidence of a new license adoption. STID retains Apache-2.0. Final original-component rights, reviewer access, and author submission facts remain unresolved. No DOI, public hosting, accepted paper, or submission is claimed.
