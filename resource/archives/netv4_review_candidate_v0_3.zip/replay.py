# -*- coding: utf-8 -*-
"""Replay saved center predictions using only the extracted artifact directory."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent

def digest(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
    return h.hexdigest()

def predict(variant,folder,model):
    with np.load(ROOT/"data"/variant/"history.npz",allow_pickle=False) as z:history=z["history"]
    with np.load(ROOT/"data"/variant/"splits.npz",allow_pickle=False) as z:indices=z["test"]
    x=history[indices];center=x[:,:,0]
    if model=="LastValue":p=np.repeat(center[:,-1:],12,axis=1)
    elif model=="HistoricalMean":p=np.repeat(center.mean(axis=1,keepdims=True),12,axis=1)
    elif model=="LinearDrift":p=center[:,-1:]+(center[:,-1:]-center[:,-4:-3])/3*np.arange(1,13)[None,:]
    elif model.startswith("Ridge"):
        f=center.copy() if model=="RidgeCenter" else x.reshape(len(x),-1).copy()
        with np.load(folder/"weights.npz",allow_pickle=False) as z:
            f-=z["mean"];f/=z["scale"]
            p=f.astype(np.float64)@z["coef"].T+z["intercept"]
    else:
        import torch
        torch.set_num_threads(4)
        sys.path.insert(0,str(ROOT/"vendor/stid"))
        from arch import STID
        network=STID(num_nodes=9,node_dim=32,input_len=12,input_dim=1,embed_dim=64,output_len=12,num_layer=3,
                     temp_dim_tid=0,temp_dim_diw=0,time_of_day_size=96,day_of_week_size=7,if_T_i_D=False,if_D_i_W=False,if_node=True)
        network.load_state_dict(torch.load(folder/"best_weights.pt",map_location="cpu",weights_only=True));network.eval()
        scale=json.loads((folder/"scaler.json").read_text(encoding="utf-8"))
        normalized=((x-scale["mean"])/scale["std"])[:,:,:,None]
        parts=[]
        with torch.no_grad():
            for i in range(0,len(x),512):
                y=network(torch.from_numpy(normalized[i:i+512]),None,batch_seen=0,epoch=0,train=False)[:,:,0,0]
                parts.append(y.numpy()*scale["std"]+scale["mean"])
        p=np.concatenate(parts)
    return np.maximum(p,0).astype(np.float32),indices

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--check-only",action="store_true");args=parser.parse_args()
    manifest=json.loads((ROOT/"MANIFEST.json").read_text(encoding="utf-8"))
    for r in manifest["files"]:
        assert digest(ROOT/r["path"])==r["sha256"],r["path"]
    verified=[]
    for variant in ["packaged","working"]:
        for p in sorted((ROOT/"runs"/variant).glob("*/result.json")):
            result=json.loads(p.read_text(encoding="utf-8"));folder=p.parent
            with np.load(folder/"predictions.npz",allow_pickle=False) as z:stored=z["prediction"];indices=z["test_indices"]
            delta=None
            if not args.check_only:
                # Inference completes before any future targets or masks are opened.
                prediction,pred_indices=predict(variant,folder,result["model"])
                assert np.array_equal(indices,pred_indices)
                delta=float(np.max(np.abs(prediction-stored)))
                assert np.allclose(prediction,stored,atol=.001,rtol=2e-5)
            with np.load(ROOT/"data"/variant/"targets.npz",allow_pickle=False) as z:
                truth=z["future"][indices,:,0].astype(np.float64);ev=z["is_event"][indices];mask=z["future_event_mask"][indices]
            with np.load(ROOT/"data"/variant/"analysis_metadata.npz",allow_pickle=False) as z:source=z["source"][indices]
            selection={"all_steps":np.ones(truth.shape,dtype=bool),"event_steps":mask}
            for name,row_mask in [("future_event_windows",mask.any(1)),("no_future_event_windows",~mask.any(1)),("event_samples",ev),("control_samples",~ev)]:
                selection[name]=np.repeat(row_mask[:,None],12,1)
            for tag in np.unique(source):selection["source:"+str(tag)]=np.repeat((source==tag)[:,None],12,1)
            for metric in result["metrics"]:
                chosen=selection[metric["group"]];error=stored.astype(np.float64)[chosen]-truth[chosen]
                assert abs(float(np.abs(error).mean())-metric["mae"])<1e-9
                assert abs(float(np.sqrt(np.mean(error**2)))-metric["rmse"])<1e-9
                den=float(np.abs(truth[chosen]).sum())
                assert den==0 or abs(float(np.abs(error).sum()/den*100)-metric["wmape"])<1e-9
                assert int(chosen.sum())==metric["points"]
            verified.append({"variant":variant,"model":result["model"],"seed":result["seed"],"max_abs_replay_error":delta})
    assert len(verified)==16
    print(json.dumps({"checked_files":len(manifest["files"]),"checked_runs":len(verified),"inference_replayed":not args.check_only,"results":verified},indent=2))

if __name__=="__main__":main()
