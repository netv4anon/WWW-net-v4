"""Execute unmodified mlcroissant Dataset.records against version-bound fixtures."""
import contextlib,hashlib,importlib.metadata,io,json,logging,os,platform,sys,traceback,warnings,zipfile
from datetime import date,datetime
from pathlib import Path
p=Path(__file__).resolve().parent
os.environ['CROISSANT_CACHE']=str(Path(sys.executable).parent/'croissant_cache')
import mlcroissant as mc
import pandas as pd
import requests
# The fixture is local; prevent an accidental whole-archive download.
network_attempts=[]
def forbidden_request(self,method,url,*args,**kwargs):
    network_attempts.append({'method':method,'url':str(url).split('?')[0]})
    raise RuntimeError('Network disabled during local prefix experiment')
requests.sessions.Session.request=forbidden_request
out=p/'execution'; out.mkdir(exist_ok=True)
log=io.StringIO(); handler=logging.StreamHandler(log); logging.getLogger().addHandler(handler)
logging.getLogger().setLevel(logging.WARNING)
def save(name,value):
    (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def error_info(e): return {'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
def val(v):
    if v is None: return None
    if isinstance(v,(datetime,date,pd.Timestamp)): return v.isoformat()
    if isinstance(v,bytes): return v.decode('utf-8')
    if hasattr(v,'item'): return val(v.item())
    return v
runtime={'python':sys.version,'platform':platform.platform(),'packages':{z.metadata['Name']:z.version for z in importlib.metadata.distributions()},'module_file':mc.__file__}
source_check=[]
with zipfile.ZipFile(p/'sources/mlcroissant-1.1.1-py2.py3-none-any.whl') as z:
    for name in z.namelist():
        if name.startswith('mlcroissant/') and name.endswith('.py'):
            actual=Path(mc.__file__).parent.parent/name
            assert actual.read_bytes()==z.read(name),name
            source_check.append(name)
runtime['unmodified_reference_python_files_verified']=len(source_check)
original=json.loads((p/'sources/traffident_metadata_v5.json').read_text(encoding='utf-8-sig'))
results={'runtime':runtime,'scope':'complete Dataset.records on a 124-record derived v5 prefix fixture; not whole archive','original_full_metadata_syntax':{},'conditions':[]}
try:
    ds=mc.Dataset(jsonld=original)
    results['original_full_metadata_syntax']={'success':True,'record_sets':[rs.id for rs in ds.metadata.record_sets],'full_source_records_requested':False}
except Exception as e: results['original_full_metadata_syntax']={'success':False,'error':error_info(e),'full_source_records_requested':False}
fixture=p/'fixtures/incidents_y2023_prefix.tsv'
for label,meta,sep in [('original_declaration','original_declaration.json',','),('mime_corrected','mime_corrected.json','\t')]:
    item={'condition':label,'metadata_file':'fixtures/'+meta,'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest()}
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        try:
            frame=pd.read_csv(fixture,sep=sep)
            item['raw_pandas_parse']={'success':True,'rows':len(frame),'columns':list(frame.columns)}
        except Exception as e: item['raw_pandas_parse']={'success':False,'error':error_info(e)}
        try:
            ds=mc.Dataset(jsonld=p/'fixtures'/meta,mapping={'incidents_y2023.csv_fileobject':fixture})
            item['dataset_construction']={'success':True}
        except Exception as e:
            item['dataset_construction']={'success':False,'error':error_info(e)}
            item['records']={'executed':False}
        else:
            records=[]
            try:
                for rec in ds.records('incidents_y2023.csv'):
                    records.append(rec)
                serialized=[{str(k):val(v) for k,v in r.items()} for r in records]
                save(label+'_records.json',serialized)
                item['records']={'executed':True,'success':True,'yielded':len(records),'first_record':serialized[0] if records else None,'first_record_types':{str(k):type(v).__name__ for k,v in records[0].items()} if records else {},'output':label+'_records.json'}
            except Exception as e:
                item['records']={'executed':True,'success':False,'yielded':len(records),'error':error_info(e)}
        item['warnings']=[{'category':x.category.__name__,'message':str(x.message)} for x in w]
    results['conditions'].append(item)
results['network_attempts']=network_attempts
save('RESULTS.json',results)
(out/'REFERENCE_LOG.txt').write_text(log.getvalue(),encoding='utf-8')
print(json.dumps({'syntax':results['original_full_metadata_syntax'],'conditions':[{'name':x['condition'],'construction':x['dataset_construction'],'records':{k:v for k,v in x['records'].items() if k not in ('error','first_record','first_record_types')},'error':x['records'].get('error',{}).get('message','')[:450]} for x in results['conditions']],'network_attempts':network_attempts},ensure_ascii=False,indent=2))
