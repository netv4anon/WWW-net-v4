﻿# Bounded reference-reader feasibility check

Goal: determine whether the existing public Croissant metadata has an actual,
version-consistent reuse problem relevant to the current manuscript.

First inspect the latest stable PyPI mlcroissant reference-reader release as of
the current date, bind its version and distribution hash, and read the relevant
source. This is code/literature acquisition, not a traffic experiment.
Maximum reference source/metadata acquisition: 10 MB.

Determine delimiter handling, local-file mapping, field lookup and declared
date conversion. Do not substitute a weaker parser to manufacture a failure.
Do not claim that version 8 file contents violate a version 5 declaration.
If source behavior resolves the suspected delimiter issue, close that issue.

Only after a specific discrepancy is identified may a separate execution
protocol request a small sample of the metadata's explicitly named version 5.
A metadata syntax check, raw-column parse, typed-record load and forecasting
semantics are separate claims. No whole traffic archive, fitting, new predictive
configuration, or external message is authorized by this protocol.
