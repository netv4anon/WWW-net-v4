﻿"""Independent stdlib-only audit; does not call pandas or mlcroissant."""
import copy,csv,hashlib,io,json,math,re
from datetime import datetime
from pathlib import Path
p=Path(__file__).resolve().parent
def read(n): return json.loads((p/n).read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
b=read('SOURCE_BINDING.json'); results=read('execution/RESULTS.json')
raw=(p/'sources/v5_incidents_y2023_prefix.bin').read_bytes()
fixture=(p/'fixtures/incidents_y2023_prefix.tsv').read_bytes()
assert fixture==raw[:len(fixture)] and sha(fixture)==b['fixture_sha256']
assert sha(raw)==b['prefix_sha256']
listing=read('sources/v5_file_list.json')
assert next(z['totalBytes'] for z in listing['datasetFiles'] if z['name']=='incidents_y2023.csv')==63009827
assert b['content_range']=='bytes 0-16383/63009827'
a=read('fixtures/original_declaration.json');c=read('fixtures/mime_corrected.json')
changed=copy.deepcopy(a); changed['distribution'][0]['encodingFormat']='text/tab-separated-values'
assert changed==c
rows=list(csv.DictReader(io.StringIO(fixture.decode('utf-8'),newline=''),delimiter='\t',strict=True))
loaded=read('execution/mime_corrected_records.json')
assert len(rows)==len(loaded)==124
fields=c['recordSet'][0]['field']; comparisons=[];lexical=[]; fail=[]; date_ambiguous=0
for i,(src,out) in enumerate(zip(rows,loaded)):
    assert set(out)==set(f['@id'] for f in fields)
    for f in fields:
        key=f['@id']; col=f['source']['extract']['column']; typ=f['dataType'][0]
        value=src[col]; actual=out[key]
        if value=='': expected=None; match=actual is None
        elif typ=='sc:Float': expected=float(value);match=actual==expected
        elif typ=='sc:Date':
            expected=datetime.strptime(value,'%m/%d/%Y %H:%M:%S').isoformat()
            match=actual==expected
            month,day=map(int,value.split()[0].split('/')[:2])
            date_ambiguous+=int(month<=12 and day<=12 and month!=day)
        else:
            expected=value;match=actual==expected
            if not match and col in ('Latitude','Longitude'):
                try:
                    if float(actual)==float(value):
                        lexical.append({'row':i,'column':col,'source':value,'loaded':actual})
                        match=True
                except (TypeError,ValueError): pass
        comparisons.append((i,col,match))
        if not match: fail.append({'row':i,'column':col,'source':value,'expected':expected,'loaded':actual})
assert not fail,fail[:10]
original,corrected=results['conditions']
assert results['original_full_metadata_syntax']['success']
assert all(x['dataset_construction']['success'] for x in results['conditions'])
assert original['records']['success'] is False and original['records']['yielded']==0
assert 'Column "incident_id" does not exist' in original['records']['error']['traceback']
assert len(original['raw_pandas_parse']['columns'])==1
assert corrected['records']['success'] and corrected['records']['yielded']==len(rows)
assert len(corrected['raw_pandas_parse']['columns'])==12
assert results['network_attempts']==[]
report={'passed':True,'independent_checker':'Python stdlib csv, datetime and direct JSON comparison; no pandas/mlcroissant','rows':len(rows),'fields_per_row':len(fields),'field_comparisons':len(comparisons),'value_mismatches':fail,'numeric_text_lexical_changes':lexical,'numeric_text_lexical_change_count':len(lexical),'source_datetime_format_used_for_comparison':'%m/%d/%Y %H:%M:%S','date_values_compared':len(rows),'lexically_ambiguous_month_day_values':date_ambiguous,'calendar_date_ground_truth_independently_established':False,'timezone_established':False,'datetime_check_scope':'Matches explicit month-first reading of the source strings; physical date/clock not validated','condition_diff_exactly_mime_only':True,'fixture_prefix_binding_passed':True,'original_full_metadata_constructed':True,'full_archive_load_executed':False,'typed_reference_load_repaired':True,'forecast_utility_established':False}
(p/'VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='numeric_text_lexical_changes'},ensure_ascii=False,indent=2))
