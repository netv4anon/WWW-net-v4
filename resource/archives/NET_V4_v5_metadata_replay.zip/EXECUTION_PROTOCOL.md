﻿# Version-consistent reference execution protocol

Recorded before requesting the v5 file list or contents. Existing evidence is only
that the pinned Croissant v5 declaration selects text/csv and reference release
mlcroissant 1.1.1 calls pandas.read_csv without delimiter inference for that MIME.

Acquire the public v5 file list (maximum 1 MB) and at most 16 KiB of the beginning
of incidents_y2023.csv explicitly from version 5. Require HTTP 206 and verify the
requested range, total size and storage object version. No other year, traffic
array or entire archive is requested. If version binding fails, stop this test.
Trim the prefix to a complete quoted tabular record after inspecting CSV quoting;
label it a derived prefix fixture, not the original complete file or archive.
Use the same fixture bytes for the unchanged MIME and a minimal MIME-only repair
if and only if the original bytes establish a different supported delimiter.

Keep original metadata immutable. For local execution, record every change in a
fixture manifest: project the 2023 record set and file object, remove archive
containment and unavailable whole-archive checksum, and bind a local fixture.
Those fixture binding changes are identical for both conditions. Execute the
unmodified chosen reference package with a compatible Python if available; any
partial-operation fallback must be labelled as such and cannot establish a full
Dataset.records outcome. Runtime dependency acquisition is separate from source
and data acquisition, isolated in the workspace, with no system installation.

Report schema construction, raw column parsing, typed record iteration and time
interpretation separately. An integer parsed as a 1970 nanosecond timestamp is
not automatically the intended time; validate any proposed date format against
visible field bytes. A second repair requires a disclosed post-first-result step.
Do not infer errors in the full file from uninspected suffixes. A successful small
fixture establishes only those records. Do not infer forecast effects, a new
algorithm, an expressive limitation of Croissant, or sufficient WWW novelty.
No model fitting, predictions, external messages, submission, or whole archive.
