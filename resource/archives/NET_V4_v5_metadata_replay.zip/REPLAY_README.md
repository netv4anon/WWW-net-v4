# Version-bound Croissant prefix replay

This local companion checks one declared v5 incident file, not the entire TraffiDent archive. It contains a 124-record derived source prefix, original metadata, original/MIME-corrected local fixture metadata, saved outcomes and a standard-library verifier. Source metadata preserves the source's Attribution-NonCommercial 4.0 license declaration; no new license for upstream content is asserted.

Use Python 3.12 in an isolated environment. Install requirements-reference.txt there. The environment must use mlcroissant 1.1.1 exactly; run_reference.py compares every package Python source file against the included, hashed reference wheel before execution. It does not alter the reference implementation. Source metadata and fixture hashes are recorded in SOURCE_BINDING.json.

Commands from this directory:

    python -X utf8 run_reference.py
    python -X utf8 verify_records.py

run_reference.py uses local-file mapping and forbids requests during execution. It writes execution/RESULTS.json and the corrected records. Expected result: both local metadata objects construct; original MIME yields zero records because incident_id is absent; corrected MIME yields 124 records. verify_records.py independently compares 1,488 values, checks identical fixtures and the one-field contrast. Saved result verification alone needs only Python's standard library.

Datetime verification assumes the explicit format %m/%d/%Y %H:%M:%S. It does not establish month/day ground truth or timezone. No original whole-archive checksum is applied to a partial fixture. No source traffic arrays, neural models, forecasts or publication-performance claim are included.

The raw signed redirect query is excluded; sanitized response headers retain status, content range and object path. Downloaded package/runtime archives remain local development support, separate from this small companion. The zip does not include an interpreter or third-party dependencies other than the selected reference wheel used for source identity checking.
