# -*- coding: utf-8 -*-
"""Reconstruct the four generated arms from fixed profiles, contexts and seed."""
import ast
from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
for record in json.loads((HERE/"MANIFEST.json").read_text(encoding="utf-8"))["files"]:
    assert hashlib.sha256((HERE/record["path"]).read_bytes()).hexdigest()==record["sha256"],record["path"]
tree=ast.parse((HERE/"legacy_generator.py").read_text(encoding="utf-8"))
namespace={}
exec(compile(tree,"legacy_generator.py","exec"),namespace)
generate=namespace["generate_ar1_timeseries"]
full=namespace["apply_ev_perturbation_v4"]
pulse=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="apply_ev_perturbation_v4")
pulse.name="pulse_without_recovery"
condition=ast.dump(ast.parse("ev_end < n_steps and ev_end > 0",mode="eval").body)
found=[n for n in pulse.body if isinstance(n,ast.If) and ast.dump(n.test)==condition]
assert len(found)==1
pulse.body=[n for n in pulse.body if n is not found[0]]
exec(compile(ast.fix_missing_locations(ast.Module(body=[pulse],type_ignores=[])),"pulse_only","exec"),namespace)
contexts=json.loads((HERE/"paired_results/contexts.json").read_text(encoding="utf-8"))
with np.load(HERE/"profiles.npz",allow_pickle=False) as z:profiles=z["profiles"]
with np.load(HERE/"paired_results/history.npz",allow_pickle=False) as z:history=z["history"]
with np.load(HERE/"paired_results/targets.npz",allow_pickle=False) as z:future=z["future"];masks=z["paired_future_event_mask"]
stored=np.concatenate([history,future],axis=2)
assert profiles.shape==(256,7,96)
np.random.seed(20260909)
for pair,context in enumerate(contexts):
    date=datetime.fromisoformat(context["context_time"])
    b,mu=generate(profiles[pair],date,noise_scale=.025,year=date.year)
    arguments={k:context[k] for k in ["distance_deg","severity_level","dispatch_sec","response_sec","ev_start","ev_duration"]}
    before=np.random.get_state()
    f,mask=full(b,mu,**arguments)
    after=np.random.get_state()
    np.random.set_state(before)
    p,_=namespace["pulse_without_recovery"](b,mu,**arguments)
    np.random.set_state(before)
    r,_=full(b,mu,**{**arguments,"severity_level":0})
    np.random.set_state(after)
    actual=np.stack([b,p,r,f]).astype(np.float32)
    assert np.array_equal(actual,stored[:,pair]),pair
    assert np.array_equal(mask[12:].astype(bool),masks[pair])
print(json.dumps({"exact_context_replays":len(contexts),"arms_per_context":4,
                  "new_random_contexts":0,"scope":"generated diagnostic replay; not complete legacy snapshot regeneration"}),flush=True)
subprocess.run([sys.executable,"-B","-X","utf8",str(HERE/"verify_paired.py")],cwd=HERE,check=True)
