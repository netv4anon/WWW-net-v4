# NET-V4 paired construction diagnostic

This is a companion to the preserved v0.3 NET-V4 artifact, not a new observational dataset or a replacement for its 33,076-row snapshots. It reuses 256 contexts selected during earlier development, with four arms sharing calendar, profile, stochastic background, and event parameters: B background, P pulse without recovery, R recovery with severity zero disabling the pulse, F full legacy operation. Two arms replay a previously saved prototype; P/R add 512 constructed diagnostic rows. No learned model or traffic simulator is run.

In the extracted folder run:

```sh
python -B replay_construction.py
```

This uses Python and NumPy only (checked on Python 3.8.10 / NumPy 1.24.4). It verifies file hashes, regenerates all four arms from fixed profiles and contexts, compares exact float32 arrays, and independently verifies the twelve no-training prediction configurations, all saved metrics, and paired contrasts. The source tree, network, GPU, and original project are not needed. A fresh environment installation or cross-platform identity has not been tested.

Files under paired_results separate history inputs, targets/offline masks, parameters, predictions, scores, and per-context contrasts. Primary scoring uses all twelve future steps; secondary scoring uses the same offline event-mask positions in each arm. The latter are not observed events in B or R. The generation script legitimately uses offline event parameters and profiles to define synthetic scenarios; forecasting consumes only history values. The two stages have different information boundaries.

All three predictors have larger WMAPE for F than B. Full-operation MAE rises for last value and linear drift and falls slightly for history mean, while recovery reduces average MAE relative to pulse only. The experiment does not decompose the main snapshot error gap, estimate real traffic effects, establish independent resource novelty, or prove WWW scope. Profiles pool legacy periods and the contexts have been development-exposed.

The generator function bodies retain historical comments and the original MIT notice. The data declaration is preserved verbatim and still contains historical source/author/DOI errors; read SOURCE_ATTRIBUTION.md for the verified correction to Fire Incident Dispatch Data. The companion does not create a new blanket license or confirm final original-component rights. It remains a local candidate; no public deposit, DOI, or review access is claimed.
