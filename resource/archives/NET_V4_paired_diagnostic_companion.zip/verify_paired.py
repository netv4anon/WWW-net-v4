# -*- coding: utf-8 -*-
"""Independently rescore the finite paired diagnostic and check intervention structure."""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
OUT = HERE / "paired_results"
with np.load(OUT / "history.npz",allow_pickle=False) as z:
    history = z["history"]
with np.load(OUT / "targets.npz",allow_pickle=False) as z:
    target = z["future"]; mask = z["paired_future_event_mask"]
with np.load(OUT / "predictions.npz",allow_pickle=False) as z:
    prediction = z["prediction"]
contexts = json.loads((OUT / "contexts.json").read_text(encoding="utf-8"))
saved = json.loads((OUT / "results.json").read_text(encoding="utf-8"))
assert history.shape == target.shape == (4,256,12)
assert prediction.shape == (3,4,256,12)
all_values = np.concatenate([history,target],axis=2)
max_prediction_difference = 0.
max_recovery_difference = 0.
for arm in range(4):
    for pair in range(256):
        past = history[arm,pair]
        expected = [np.repeat(past[-1],12),np.repeat(past.mean(),12),
                    past[-1]+(past[-1]-past[-4])/3.*np.arange(1,13)]
        for model in range(3):
            difference = float(np.max(np.abs(np.maximum(expected[model],0)-prediction[model,arm,pair])))
            max_prediction_difference = max(max_prediction_difference,difference)
            assert np.allclose(np.maximum(expected[model],0),prediction[model,arm,pair],atol=.001,rtol=2e-5)
for pair,context in enumerate(contexts):
    start=context["ev_start"]; end=start+context["ev_duration"]
    b,p,r,f=all_values[:,pair]
    assert all(np.array_equal(x[:start],b[:start]) for x in [p,r,f])
    assert np.array_equal(p[end:],b[end:])
    assert np.array_equal(p[start:end],f[start:end])
    assert np.array_equal(r[:end],b[:end])
    expected=np.array(b,dtype=np.float64)
    tau=max(2.,context["response_sec"]/900.)
    for index in range(end,24):
        fraction=1.-np.exp(-(index-end)/tau)
        expected[index]=(1.-fraction)*float(b[end-1])+fraction*float(b[index])
    expected=np.clip(expected,3.,b.max()*1.3)
    max_recovery_difference=max(max_recovery_difference,float(np.abs(expected-r).max()))
    assert np.allclose(expected,r,atol=.001,rtol=2e-5)
    expected_mask=np.array([start<=t<end for t in range(12,24)])
    assert np.array_equal(expected_mask,mask[pair])
for record in saved["scores"]:
    mi=saved["models"].index(record["model"]); ai=saved["arms"].index(record["arm"])
    choose=np.ones((256,12),bool) if record["population"]=="all_steps" else mask
    errors=[];truth=[]
    for pair,t in zip(*np.where(choose)):
        errors.append(float(prediction[mi,ai,pair,t])-float(target[ai,pair,t]))
        truth.append(abs(float(target[ai,pair,t])))
    a=sum(abs(e) for e in errors)
    independent={"mae":a/len(errors),"rmse":(sum(e*e for e in errors)/len(errors))**.5,
                 "wmape":100*a/sum(truth),"points":len(errors)}
    for key,value in independent.items():
        assert abs(value-record[key])<1e-8,(record,key)
with (OUT / "pair_differences.csv").open(encoding="utf-8") as f:
    rows=list(csv.DictReader(f))
coefficients={"F-B":[-1,0,0,1],"P-B":[-1,1,0,0],"R-B":[-1,0,1,0],
              "F-P":[0,-1,0,1],"F-P-R+B":[1,-1,-1,1]}
for record in rows:
    pair=int(record["pair_id"]); mi=saved["models"].index(record["model"])
    choose=np.ones(12,bool) if record["population"]=="all_steps" else mask[pair]
    loss=[]
    for ai in range(4):
        delta=prediction[mi,ai,pair,choose].astype(np.float64)-target[ai,pair,choose].astype(np.float64)
        loss.append(float(np.abs(delta).mean()))
    value=sum(c*x for c,x in zip(coefficients[record["contrast"]],loss))
    assert abs(value-float(record["paired_mae_difference"]))<1e-9
for summary in saved["contrasts"]:
    selected=[float(r["paired_mae_difference"]) for r in rows if all(r[k]==summary[k] for k in ["model","population","contrast"])]
    assert len(selected)==summary["pairs"]
    assert abs(np.mean(selected)-summary["mean_paired_difference"])<1e-9
    assert abs(np.median(selected)-summary["median_paired_difference"])<1e-9
    assert sum(v<0 for v in selected)==summary["lower"]
    assert sum(v==0 for v in selected)==summary["equal"]
    assert sum(v>0 for v in selected)==summary["higher"]
report={"contexts":256,"arms":4,"prediction_configurations":12,
        "scored_model_arm_populations":len(saved["scores"]),"checked_pair_contrasts":len(rows),
        "original_pair_replay_verified_by_generation_run":saved["original_pair_replay_max_abs_difference"]==0,
        "independent_prediction_max_abs_difference":max_prediction_difference,
        "independent_recovery_max_abs_difference":max_recovery_difference,
        "all_saved_metrics_recomputed":True,"all_paired_contrasts_recomputed":True,
        "new_fits":0,"new_traffic_simulations":0,
        "scope":"Internal verification of a finite generated diagnostic; no real-world or WWW relevance claim follows."}
# Keep the extracted evidence immutable; verification is printed below.
print(json.dumps(report,indent=2))
