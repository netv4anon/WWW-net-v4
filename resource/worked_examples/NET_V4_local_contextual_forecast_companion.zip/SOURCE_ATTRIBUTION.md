# Source and scope

Model: Qwen/Qwen2.5-3B-Instruct, revision aa8e72537993ba99e69dfaafa59ed015b17504d1, https://huggingface.co/Qwen/Qwen2.5-3B-Instruct/tree/aa8e72537993ba99e69dfaafa59ed015b17504d1 . Qwen Research License. Only metadata and the license are packaged, not weights or a trained derivative.

Traffic construction: existing custom probes bound to Context is Key commit 73f46016f8c5643bf6799ca31875eab3e8d0d075 and TrafficFresh commit 72f9682ad1ce00006090e61adedff5898ec3f963. The source acquisition was a prefix, not the complete source dataset; station histories use a disclosed fixed-series loader. Sensors 423339 and 10130110 were selected sequentially in earlier development. The plateau target preserves the inspected generator operation, and pointwise scaling is an explicitly hypothetical alternative. Neither is physical truth. See included earlier binding records and existing source companion for construction regeneration.

This capsule can replay saved-forecast scoring and audit input/target laws. It is not the official CiK benchmark exporter, official model predictions, a blindly selected cohort, independent incidents or a new dataset collection. The original NET-V4 12-to-12 core and the independent traffic-resource v0.7 are separate artifacts.
