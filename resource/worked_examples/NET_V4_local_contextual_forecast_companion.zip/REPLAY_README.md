# Replay the fixed local-model scores

This capsule contains frozen inputs, target laws, all raw outputs and forecasts. It is a new local Qwen experiment on two exposed custom probes, not a reproduction of official CiK predictions. It does not contain model weights.

With Python and numpy installed, run from the capsule directory:

    python -X utf8 score_experiment.py
    python -X utf8 verify_experiment.py

The first command re-scores sealed forecasts under both laws. The second independently checks scalar losses, laws, prompt pairs, parsing and the fixed decision gate. Neither command fits or executes a predictor.

For model provenance see MODEL_MANIFEST.json and model_metadata.json. Inference originally used Torch 2.4.1+cu118, Transformers 4.46.3 and FP16 on an RTX 2080 Ti. run_inference.py protects sealed outputs against reruns; reproducing inference requires a new directory, verified fixed checkpoint files under model/, and no prior results seal. Copy protocol-bound scripts without editing them. Output formats and the invalid-answer fallback are specified in PROTOCOL.json. Regenerated outputs on another hardware/software configuration are a new execution, not guaranteed byte identical.

The source histories, targets and reference-rule predictions were copied byte-for-byte from the previous two-station probes. SOURCE_BINDING.json records hashes. Original background futures are scoring-only data. No forecast program reads them. Original NET-V4 is a separate 12-to-12 task.

Qwen weights are research-licensed and are not redistributed here; the fixed repository URL and its LICENSE are retained under model/. Source relationships and scope are in SOURCE_ATTRIBUTION.md.
