﻿import json,hashlib,math,re
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
P=Path(__file__).absolute().resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
errors=[];checked=0;max_error=0.0

def close(a,b,label):
 global checked,max_error
 checked+=1
 if a is None or b is None:assert a is b,label;return
 e=abs(float(a)-float(b));max_error=max(max_error,e)
 assert math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-11),(label,a,b)

def average(a):return sum(a)/len(a) if a else None

for sealname in ['PROTOCOL_SEAL.json','results/PREDICTION_SEAL.json']:
 s=json.loads((P/sealname).read_text())
 for n,h in s['files'].items():assert sha(P/n)==h,(sealname,n)
raw=[json.loads(l) for l in (P/'results'/'RAW_OUTPUTS.jsonl').read_text(encoding='utf-8').splitlines()]
prompts=[json.loads(l) for l in (P/'PROMPTS.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(raw)==len(prompts)==128
pred=np.load(P/'results'/'PREDICTIONS.npz',allow_pickle=False)
for out,prompt in zip(raw,prompts):
 assert out['case_id']==prompt['case_id']
 assert out['prompt_sha256']==hashlib.sha256(json.dumps(prompt['messages'],ensure_ascii=False).encode()).hexdigest()
 t=out['raw_text'].strip()
 m=re.fullmatch(r'```(?:json)?\n(.*)\n```',t,flags=re.S)
 if m:t=m.group(1).strip()
 try:
  a=json.loads(t)
  ok=isinstance(a,list) and len(a)==24 and all(type(v) in (int,float) and math.isfinite(v) and v>=0 for v in a)
 except ValueError:ok=False
 assert ok==out['valid'] and out['used_fallback']==(not ok)
 expected=a if ok else prompt['fallback']
 row=pred[out['station']+'__'+out['condition']][out['seed']]
 for x,y,z in zip(expected,out['prediction'],row):close(x,y,'raw prediction');close(x,float(z),'array prediction')
 assert bool(pred[out['station']+'__'+out['condition']+'__valid'][out['seed']])==ok
assert 'TARGETS' not in (P/'run_inference.py').read_text(encoding='utf-8-sig')
res=json.loads((P/'results'/'RESULTS.json').read_text())
station_gates=[]
for station,r in res['stations'].items():
 data=P/'data'/station
 x=np.load(data/'INPUTS.npz',allow_pickle=False);y=np.load(data/'TARGETS.npz',allow_pickle=False);baseline=np.load(data/'PREDICTIONS.npz',allow_pickle=False)
 sc=json.loads((data/'SCENARIOS.json').read_text())
 masks=[]
 for i in range(32):
  s=int(x['event_start'][i]);d=int(x['event_duration'][i]);ratio=float(x['event_ratio'][i]);roi=list(range(s,s+d));masks.append(roi)
  for t in range(24):
   v=float(y['background'][i,t]);a=ratio*float(y['background'][i,s]) if t in roi else v;b=ratio*v if t in roi else v
   close(a,float(y['reference'][i,t]),'plateau law');close(b,float(y['pointwise'][i,t]),'pointwise law')
  a=next(q for q in prompts if q['station']==station and q['seed']==i and q['condition']=='history')
  b=next(q for q in prompts if q['station']==station and q['seed']==i and q['condition']=='context')
  assert b['messages'][1]['content']==a['messages'][1]['content']+'\nAdditional context:\n'+sc[i]['scenario']
  assert a['fallback']==[float(v) for v in x['history'][i,-24:]]
  lines=a['messages'][1]['content'].split('History:\n')[1].split('\nForecast')[0].splitlines()
  parsed=[float(v) for line in lines for v in line.split('[',1)[1].rstrip(']').split(', ')]
  assert parsed==[float(format(float(v),'.10g')) for v in x['history'][i]]
 valid=[i for i in range(32) if bool(pred[station+'__history__valid'][i]) and bool(pred[station+'__context__valid'][i])]
 assert len(valid)==r['paired_valid'];local_gates=[]
 for name,ids in [('all_cases',list(range(32))),('paired_valid',valid)]:
  gains={};rel={}
  for law,key in [('plateau','reference'),('pointwise','pointwise')]:
   cell=r['analyses'][name]['target_laws'][law];eventmeans={}
   for cond in ['history','context']:
    daily=[];full=[];pooled=[];outside=[]
    for i in ids:
     losses=[abs(float(pred[station+'__'+cond][i,t])-float(y[key][i,t])) for t in range(24)]
     daily.append(average([losses[t] for t in masks[i]]));full.extend(losses);pooled.extend(losses[t] for t in masks[i]);outside.extend(losses[t] for t in range(24) if t not in masks[i])
    eventmeans[cond]=daily
    for metric,values in [('event_mae',daily),('full_mae',full),('event_pooled_mae',pooled),('outside_event_mae',outside)]:close(average(values),cell[cond][metric],(station,name,law,cond,metric))
   g=[a-b for a,b in zip(eventmeans['history'],eventmeans['context'])]
   gains[law]=average(g);rel[law]=100*gains[law]/average(eventmeans['history']) if ids and average(eventmeans['history'])>0 else None
   close(gains[law],cell['gain'],'gain');close(rel[law],cell['relative_gain_percent'],'relative gain')
   assert sum(v>1e-12 for v in g)==cell['wins'];assert sum(v<-1e-12 for v in g)==cell['losses'];assert sum(abs(v)<=1e-12 for v in g)==cell['ties']
  reversal=bool(ids and gains['plateau']*gains['pointwise']<0)
  material=bool(reversal and min(abs(rel['plateau']),abs(rel['pointwise']))>=5)
  assert reversal==r['analyses'][name]['sign_reversal'];assert material==r['analyses'][name]['material_reversal'];local_gates.append(material)
 for cell in r['reference_scores']:
  key='reference' if cell['target_law']=='plateau' else 'pointwise';q=baseline[cell['rule']]
  losses=[[abs(float(q[i,t])-float(y[key][i,t])) for t in range(24)] for i in range(32)]
  close(average([v for row in losses for v in row]),cell['full_mae'],'reference full')
  close(average([average([losses[i][t] for t in masks[i]]) for i in range(32)]),cell['event_mae'],'reference event')
 station_gates.append(len(valid)>=29 and all(local_gates))
assert all(station_gates)==res['primary_material_reversal_gate_passed']
report={'verified':True,'method':'Independent stdlib scalar metric/law/parse reconstruction; numpy only for array loading','checked_scalars':checked,'max_absolute_error':max_error,'raw_forecasts':128,'prompt_pairs_checked':64,'target_cells_checked':3072,'primary_gate_verified':True,'verified_utc':datetime.now(timezone.utc).isoformat(),'files':{n:sha(P/n) for n in ['results/RESULTS.json','results/CASE_SCORES.csv','results/PREDICTION_SEAL.json','verify_experiment.py']}}
(P/'results'/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
