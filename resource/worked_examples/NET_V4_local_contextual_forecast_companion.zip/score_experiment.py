﻿import json,hashlib,csv
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
P=Path(__file__).absolute().resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seal=json.loads((P/'results'/'PREDICTION_SEAL.json').read_text())
for name,h in seal['files'].items():assert sha(P/name)==h,name
binding=json.loads((P/'SOURCE_BINDING.json').read_text())
for name,record in binding.items():assert sha(P/'data'/name)==record['sha256'],name
pred=np.load(P/'results'/'PREDICTIONS.npz',allow_pickle=False)
result={'scope':'One local instruction model on two development-exposed dependent station probes; not official CiK reproduction','prediction_seal_sha256':sha(P/'results'/'PREDICTION_SEAL.json'),'stations':{},'new_fits':0,'new_prediction_configurations':4,'new_case_forecasts':128,'new_targets':0}
case_rows=[]
for station in ['423339','10130110']:
 x=np.load(P/'data'/station/'INPUTS.npz',allow_pickle=False);y=np.load(P/'data'/station/'TARGETS.npz',allow_pickle=False);refs=np.load(P/'data'/station/'PREDICTIONS.npz',allow_pickle=False)
 mask=np.zeros((32,24),dtype=bool)
 for i,(s,d) in enumerate(zip(x['event_start'],x['event_duration'])):mask[i,int(s):int(s+d)]=True
 valid=pred[station+'__history__valid']&pred[station+'__context__valid']
 r={'cases':32,'paired_valid':int(valid.sum()),'history_valid':int(pred[station+'__history__valid'].sum()),'context_valid':int(pred[station+'__context__valid'].sum()),'technical_gate':bool(valid.sum()>=29),'analyses':{},'reference_scores':[]}
 for selection,keep in [('all_cases',np.ones(32,dtype=bool)),('paired_valid',valid)]:
  a={'cases':int(keep.sum()),'target_laws':{}}
  for law,key in [('plateau','reference'),('pointwise','pointwise')]:
   cell={};per={}
   for cond in ['history','context']:
    err=np.abs(pred[station+'__'+cond]-y[key]);roi=np.array([err[i,mask[i]].mean() for i in range(32)])
    per[cond]=roi
    cell[cond]={'event_mae':float(roi[keep].mean()) if keep.any() else None,'full_mae':float(err[keep].mean()) if keep.any() else None,'event_pooled_mae':float(err[keep][mask[keep]].mean()) if keep.any() else None,'outside_event_mae':float(err[keep][~mask[keep]].mean()) if keep.any() else None}
   gain=per['history']-per['context'];eps=1e-12
   cell['gain']=cell['history']['event_mae']-cell['context']['event_mae'] if keep.any() else None
   cell['relative_gain_percent']=100*cell['gain']/cell['history']['event_mae'] if keep.any() and cell['history']['event_mae']>0 else None
   cell['wins']=int((gain[keep]>eps).sum());cell['ties']=int((np.abs(gain[keep])<=eps).sum());cell['losses']=int((gain[keep]<-eps).sum())
   a['target_laws'][law]=cell
   if selection=='all_cases':
    for i in range(32):case_rows.append({'station':station,'seed':i,'target_law':law,'paired_valid':bool(valid[i]),'history_event_mae':float(per['history'][i]),'context_event_mae':float(per['context'][i]),'gain':float(gain[i])})
  p=a['target_laws']['plateau'];q=a['target_laws']['pointwise']
  a['sign_reversal']=bool(keep.any() and p['gain']*q['gain']<0)
  a['material_reversal']=bool(a['sign_reversal'] and min(abs(p['relative_gain_percent']),abs(q['relative_gain_percent']))>=5)
  a['gain_difference_plateau_minus_pointwise']=(p['gain']-q['gain']) if keep.any() else None
  r['analyses'][selection]=a
 for law,key in [('plateau','reference'),('pointwise','pointwise')]:
  for name in refs.files:
   err=np.abs(refs[name]-y[key]);roi=np.array([err[i,mask[i]].mean() for i in range(32)])
   r['reference_scores'].append({'target_law':law,'rule':name,'event_mae':float(roi.mean()),'full_mae':float(err.mean()),'reused_existing_predictions':True})
 result['stations'][station]=r
result['technical_gate_passed']=all(v['technical_gate'] for v in result['stations'].values())
result['primary_material_reversal_gate_passed']=result['technical_gate_passed'] and all(a['material_reversal'] for v in result['stations'].values() for a in v['analyses'].values())
result['scored_utc']=datetime.now(timezone.utc).isoformat()
(P/'results'/'RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
with (P/'results'/'CASE_SCORES.csv').open('w',newline='',encoding='utf-8') as f:
 writer=csv.DictWriter(f,fieldnames=list(case_rows[0]));writer.writeheader();writer.writerows(case_rows)
print(json.dumps({k:v for k,v in result.items() if k!='stations'},indent=2))
for station,r in result['stations'].items():print(json.dumps({'station':station,'paired_valid':r['paired_valid'],'all_cases':r['analyses']['all_cases']},indent=2))
