﻿import json, hashlib, os, time, math
from pathlib import Path
from datetime import datetime, timezone
P=Path(__file__).absolute().resolve().parent
os.environ['HF_HOME']=str(P/'hf_cache')
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
os.environ['TOKENIZERS_PARALLELISM']='false'
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, GenerationConfig
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()

def parse_answer(text):
    t=text.strip()
    if t.startswith('```json\n') and t.endswith('\n```'):t=t[8:-4].strip()
    elif t.startswith('```\n') and t.endswith('\n```'):t=t[4:-4].strip()
    try:
        a=json.loads(t)
    except (ValueError,TypeError):return None,'invalid_json'
    if not isinstance(a,list) or len(a)!=24:return None,'not_24_element_list'
    if not all(type(v) in (float,int) and math.isfinite(v) and v>=0 for v in a):return None,'invalid_numeric_value'
    return [float(v) for v in a],None

def main():
    assert torch.cuda.is_available()
    out=P/'results'
    assert not (out/'PREDICTION_SEAL.json').exists(), 'Predictions already sealed; refusing another research run'
    seal=json.loads((P/'PROTOCOL_SEAL.json').read_text())
    for name,expected in seal['files'].items():assert sha(P/name)==expected,name
    model_seal=json.loads((P/'MODEL_MANIFEST.json').read_text())
    assert model_seal['verified'] and model_seal['revision']==json.loads((P/'PROTOCOL.json').read_text())['revision']
    records=[json.loads(line) for line in (P/'PROMPTS.jsonl').read_text(encoding='utf-8').splitlines()]
    completed=[]
    raw=out/'RAW_OUTPUTS.jsonl'
    if raw.exists():completed=[json.loads(line) for line in raw.read_text(encoding='utf-8').splitlines()]
    assert len({r['case_id'] for r in completed})==len(completed)
    assert [r['case_id'] for r in completed]==[r['case_id'] for r in records[:len(completed)]]
    assert len(completed)%4==0, 'Investigate interrupted partial batch; do not silently regenerate'
    torch.manual_seed(0);np.random.seed(0);torch.cuda.manual_seed_all(0)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False
    torch.use_deterministic_algorithms(True)
    started=time.monotonic();began=now()
    tok=AutoTokenizer.from_pretrained(str(P/'model'),local_files_only=True,trust_remote_code=False,padding_side='left')
    mdl=AutoModelForCausalLM.from_pretrained(str(P/'model'),local_files_only=True,trust_remote_code=False,torch_dtype=torch.float16,attn_implementation='sdpa').to('cuda').eval()
    config=json.loads((P/'model'/'generation_config.json').read_text())
    gen=GenerationConfig(do_sample=False,num_beams=1,max_new_tokens=384,eos_token_id=config['eos_token_id'],pad_token_id=tok.pad_token_id,bos_token_id=tok.bos_token_id,use_cache=True)
    env={'started_utc':began,'torch':torch.__version__,'transformers':__import__('transformers').__version__,'numpy':np.__version__,'gpu':torch.cuda.get_device_name(0),'dtype':str(mdl.dtype),'batch_size':4,'deterministic_algorithms':True,'generation_config':gen.to_dict(),'previous_saved_outputs':len(completed),'model_manifest_sha256':sha(P/'MODEL_MANIFEST.json'),'protocol_seal_sha256':sha(P/'PROTOCOL_SEAL.json')}
    (out/'RUNTIME.json').write_text(json.dumps(env,indent=2)+'\n')
    with raw.open('a',encoding='utf-8',buffering=1) as stream:
        for pos in range(len(completed),len(records),4):
            batch=records[pos:pos+4]
            texts=[tok.apply_chat_template(r['messages'],tokenize=False,add_generation_prompt=True) for r in batch]
            tokens=tok(texts,return_tensors='pt',padding=True,truncation=False).to('cuda')
            lengths=tokens['attention_mask'].sum(dim=1).tolist()
            assert max(lengths)+384<=mdl.config.max_position_embeddings
            batch_start=time.monotonic()
            with torch.inference_mode():ids=mdl.generate(**tokens,generation_config=gen)
            continuations=ids[:,tokens['input_ids'].shape[1]:]
            decoded=tok.batch_decode(continuations,skip_special_tokens=True)
            for r,txt,length in zip(batch,decoded,lengths):
                values,error=parse_answer(txt)
                saved={k:r[k] for k in ['case_id','station','seed','condition']}
                saved.update({'prompt_sha256':hashlib.sha256(json.dumps(r['messages'],ensure_ascii=False).encode()).hexdigest(),'prompt_tokens':length,'raw_text':txt,'valid':error is None,'parse_error':error,'prediction':values if error is None else r['fallback'],'used_fallback':error is not None,'generated_utc':now()})
                stream.write(json.dumps(saved,ensure_ascii=False)+'\n');stream.flush();os.fsync(stream.fileno())
                completed.append(saved)
            status={'completed':len(completed),'total':len(records),'valid':sum(r['valid'] for r in completed),'last_batch_seconds':round(time.monotonic()-batch_start,2),'elapsed_seconds':round(time.monotonic()-started,2),'updated_utc':now()}
            (out/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
    arrays={}
    for station in ['423339','10130110']:
        for cond in ['history','context']:
            selected=[r for r in completed if r['station']==station and r['condition']==cond]
            assert [r['seed'] for r in selected]==list(range(32))
            arrays[station+'__'+cond]=np.asarray([r['prediction'] for r in selected],dtype=np.float64)
            arrays[station+'__'+cond+'__valid']=np.asarray([r['valid'] for r in selected],dtype=bool)
    np.savez_compressed(out/'PREDICTIONS.npz',**arrays)
    final={'created_utc':now(),'scoring_has_not_started':True,'raw_outputs':len(completed),'new_fits':0,'new_prediction_configurations':4,'files':{n:sha(P/n) for n in ['results/RAW_OUTPUTS.jsonl','results/PREDICTIONS.npz','results/RUNTIME.json','PROTOCOL_SEAL.json','PROMPTS.jsonl','MODEL_MANIFEST.json']}}
    (out/'PREDICTION_SEAL.json').write_text(json.dumps(final,indent=2)+'\n');print('PREDICTIONS_SEALED',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as exc:
        with (P/'results'/'INFRASTRUCTURE_FAILURES.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'utc':now(),'type':type(exc).__name__,'message':str(exc)})+'\n')
        raise
