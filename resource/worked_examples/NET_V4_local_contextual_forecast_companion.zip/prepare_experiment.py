﻿import json, hashlib, shutil
from pathlib import Path
from datetime import datetime, timezone, timedelta
import numpy as np
P=Path(__file__).absolute().resolve().parent
B=P.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
assert not (P/'PROTOCOL_SEAL.json').exists(), 'Frozen stage must not be overwritten'
meta=json.loads((P/'model_metadata.json').read_text(encoding='utf-8'))
assert meta['sha']=='aa8e72537993ba99e69dfaafa59ed015b17504d1'
protocol={
 'title':'Local contextual forecasting under two frozen traffic target laws',
 'created_utc':now(),
 'question':'Does the direction of accident-narrative benefit change when the same forecasts are scored under plateau versus pointwise targets?',
 'scope':'New local inference on existing CiK-derived custom station probes; not reproduction of official CiK forecasts or metrics; external 168-to-24 probe, original NET-V4 12-to-12 unchanged',
 'data_status':'Previously exposed dependent constructions, not held-out confirmatory data',
 'stations':['423339','10130110'],'seeds':list(range(32)),
 'model':'Qwen/Qwen2.5-3B-Instruct','revision':meta['sha'],
 'model_selection_reason':'Fixed 3B instruction checkpoint that fits available RTX 2080 Ti and disk; selected before any model forecasts or scores',
 'inference':{'precision':'float16','device':'cuda','attn_implementation':'sdpa','do_sample':False,'num_beams':1,'max_new_tokens':384,'batch_size':4,'seed':0,'trust_remote_code':False,'input_truncation':False},
 'conditions':['history','context'],
 'prompt_contract':'Same hourly occupancy history, timestamps and output instructions; context condition appends exact original scenario; no target values, event indices, ratios as separate fields, station ID, or seed supplied to model',
 'history_format':'168 values in chronological groups of 24; first timestamp on every row; each number .10g; seven daily rows; forecast start explicit',
 'parse_policy':'Strip whitespace; optionally remove a single entire enclosing ```json or ``` fence; accept only a JSON list of exactly 24 finite numeric nonnegative values, excluding bool; no clipping, extraction, repair, or score-driven retry',
 'failure_policy':'Every malformed answer retained; replace entire failed forecast by last 24 observed values for all-case primary scoring; additionally score only cases where both conditions parse; technical success requires at least 29 paired-valid cases at EACH station. Same prompt retries allowed only for infrastructure failure before saved output; log any failure.',
 'target_laws':{'plateau':'r*v_s inside [s,s+d); v_t elsewhere (existing reference key)','pointwise':'r*v_t inside [s,s+d); v_t elsewhere'},
 'prediction_seal':'Save all 128 raw outputs and prediction arrays, then hash them before scorer loads any targets',
 'primary_metric':'Per-case event-region MAE, then unweighted mean over all 32 cases within each station; gain = history MAE - context MAE; positive means context helps',
 'material_reversal_gate':'Both stations must show opposite signs of gain across target laws, with absolute gain >= 5% of history MAE under each law, for BOTH all-case fallback scoring and paired-valid sensitivity; technical success also required',
 'secondary_metrics':['full-horizon MAE','event pooled MAE','outside-event MAE','per-case gain and win/tie/loss counts','paired-valid metrics','existing mean-profile and seasonal-naive reference scores'],
 'no_inferential_claim':'No iid p-values/confidence intervals from dependent constructions; no general LLM ranking, physical-truth claim, causal incident effect, or acceptance-probability conclusion',
 'stop_rule':'One model, one prompt template, one pass. No new station, target law, case filtering, prompt/model search, or target tuning after results; report a failed reversal gate plainly',
 'accounting':{'new_fits':0,'planned_new_prediction_configurations':4,'planned_individual_model_forecasts':128,'existing_targets_reused':True}
}
(P/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n',encoding='utf-8')
(P/'PROTOCOL_ZH.md').write_text('''# 本地上下文预测：运行前协议

固定 Qwen2.5-3B-Instruct 与公开版本 aa8e72537993ba99e69dfaafa59ed015b17504d1；FP16，贪心解码，batch=4，最长新增 384 tokens。两站各 32 个既有案例，各跑“仅历史”和“历史+原事故文字”，共 128 次案例预测、4 个站点/条件配置，0 拟合。

这不是 CiK 官方成绩复现；两站案例已经用于目标法则探索，存在窗口重叠，不作盲测或独立同分布显著性声明。它是原 NET-V4 12→12 核心任务之外的 168→24 补充验证。

预测程序只读取提前固定的提示词与历史回退值，不读取未来、目标或评分。所有原始输出和预测数组封存以后才能评分。严格解析 24 个非负有限数；无效输出保留，整条用前一天 24 小时作为预先指定的回退，并另报双条件均有效案例的敏感性结果。每站至少 29/32 双条件有效才通过技术门槛。

主要量为事件区间逐案例 MAE 均值之差：仅历史减有上下文，正值表示文字有帮助。在每站、每种目标下分别计算。要支持实质反转，两个站点均须在两种目标法则下改变收益符号，且两边幅度都达到对应历史 MAE 的 5%，回退全样本与双有效子集均成立。否则明确写反转假设未获支持，不换模型、提示词、站点或目标追逐反转。

只作描述统计，保留逐案例结果、无效率、全未来/事件区间/事件外指标与既有简单规则参照。真实模型输出能增加实证内容，不能自动建立 WWW 新颖性或录用把握。
''',encoding='utf-8')
system='You forecast an hourly numeric time series. Use only the supplied history and any additional context. Return exactly one JSON array of 24 finite nonnegative numbers in chronological order. Do not return prose or code fences.'
records=[]; binding={};fallback={}
for station,rel in [('423339','www_contribution_calibration_2026-10-08'),('10130110','target_law_replication_2026-10-08')]:
 src=B/rel/'probe'; dst=P/'data'/station; dst.mkdir(parents=True,exist_ok=True)
 for name in ['INPUTS.npz','SCENARIOS.json','TARGETS.npz','PREDICTIONS.npz']:
  shutil.copy2(str(src/name),str(dst/name))
  binding[station+'/'+name]={'source':str(Path('..')/rel/'probe'/name),'sha256':sha(dst/name)}
 arr=np.load(dst/'INPUTS.npz',allow_pickle=False)
 scenarios=json.loads((dst/'SCENARIOS.json').read_text(encoding='utf-8'))
 assert arr['history'].shape==(32,168)
 for i,sc in enumerate(scenarios):
  assert sc['seed']==i and int(arr['seed'][i])==i
  hist=arr['history'][i]; start=datetime.fromisoformat(sc['history_start']); future=datetime.fromisoformat(sc['forecast_start'])
  assert future==start+timedelta(hours=168)
  rows=['{}: [{}]'.format((start+timedelta(hours=k)).isoformat(sep=' '),', '.join(format(float(v),'.10g') for v in hist[k:k+24])) for k in range(0,168,24)]
  user=sc['background']+' The measured variable is traffic occupancy (%).\nEach row below contains 24 consecutive hourly observations, beginning at its timestamp. Rows are consecutive and chronological.\nHistory:\n'+'\n'.join(rows)+'\nForecast the next 24 hourly occupancy values, beginning at '+sc['forecast_start']+'.'
  for cond in ['history','context']:
   u=user+ ('\nAdditional context:\n'+sc['scenario'] if cond=='context' else '')
   records.append({'case_id':station+'_'+str(i).zfill(2)+'_'+cond,'station':station,'seed':i,'condition':cond,'messages':[{'role':'system','content':system},{'role':'user','content':u}],'fallback':hist[-24:].astype(float).tolist()})
(P/'PROMPTS.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records),encoding='utf-8')
(P/'SOURCE_BINDING.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8')
# Preserve blocked goal history, then start a distinct resumed audit; never claim the tool itself was reactivated.
backup=P/'live_entries_before';backup.mkdir(exist_ok=True)
for f in ['DECISION.json','WWW_SCIENTIFIC_GOAL_AUDIT.json','README_ZH.md']:
 shutil.copy2(str(B/f),str(backup/f))
audit=json.loads((B/'WWW_SCIENTIFIC_GOAL_AUDIT.json').read_text(encoding='utf-8'))
audit['previous_blocked_audits']=audit.get('previous_blocked_audits',[])+[dict(audit)]
audit.update({'resumed_utc':now(),'resumed_by':'User can continue','current_goal_turn_classification':'new_bounded_experiment_in_preparation','current_turn_changed_scientific_evidence':False,'consecutive_blocked_turns':0,'blocked_threshold_satisfied':False,'safe_next_scientific_action_identified':True,'current_turn_work':'Freeze one local instruction-model experiment on existing custom probes','goal_tool_status_observed':'blocked','goal_status':'blocked','session_work_resumed':True,'goal_complete':False,'new_predictions':0,'new_scores':0,'tracked_live_experiment_handle':None})
(B/'WWW_SCIENTIFIC_GOAL_AUDIT.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'prompts':len(records),'protocol_written_before_inference':True,'source_files':len(binding),'model_bytes':sum(x['size'] for x in json.loads((P/'model_tree.json').read_text()) if x['path']!='.gitattributes')},indent=2))
